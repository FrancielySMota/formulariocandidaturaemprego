function myfunction() 
{
alert("Recebemos seu currículo 😎! Agora é só relaxar que, em breve entraremos em contato com você,");
}